<h1 align="center">Sponsors &amp; Backers</h1>

swf2js.js is an MIT-licensed open source project. It's an independent project with its ongoing development made possible entirely thanks to the support by these awesome backers. If you'd like to join them, please consider:

<h2 align="center">Backers via Patreon</h2>

- Tazya Kiuchi  
- weep  
- tonkatsutaro  
- miyag3  
